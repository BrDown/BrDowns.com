// main code

// waits for all of the jsons before doing anything
var startOffsetX = 0;
var startOffsetY = 0;
var offsetX = 0;
var offsetY = 0;
var totaloffsetX = 0;
let tempLink = null;
var totaloffsetY = 0;
var mouseIsDown = false;
var zoom = 1
var link;
// var nodes;
let linker2 = false
var togged = true;
var toggedDes = false;
let nodes = JSON.parse(localStorage.getItem('nodes'))
let links = JSON.parse(localStorage.getItem('links'))
let nodePosition = JSON.parse(localStorage.getItem('nodePosition'))

// console.log(nodePosition)

function RESETLOCALSTOARTE(){
  localStorage.setItem('nodes',`[{\"id\":\"node4\",\"x\":0.6750788643533123,\"y\":0.6661849710982659},{\"id\":\"13126719\",\"x\":0.5020026702269693,\"y\":0.4956647398843931},{\"id\":\"319905\",\"x\":1.1904296875,\"y\":0.3565320870020541},{\"id\":\"1225927\",\"x\":0.65478515625,\"y\":0.7922780249636494},{\"id\":\"6755221\",\"x\":0.45746962115796996,\"y\":0.6575144508670521},{\"id\":\"2866431\",\"x\":1.134765625,\"y\":0.43038733072435836},{\"id\":\"9477608\",\"x\":-0.197509765625,\"y\":0.19928199396175683},{\"id\":\"8659983\",\"x\":-0.42578125,\"y\":0.2795995715097627},{\"id\":\"15153632\",\"x\":-0.483642578125,\"y\":0.14973744965726551},{\"id\":\"2487250\",\"x\":0.410888671875,\"y\":0.5100894629338996},{\"id\":\"820187\",\"x\":0.14501953125,\"y\":0.5725586748897942},{\"id\":\"4249941\",\"x\":-0.0390625,\"y\":0.326066844044267},{\"id\":\"12140456\",\"x\":0.093994140625,\"y\":0.3971525161269849},{\"id\":\"2579631\",\"x\":0.000732421875,\"y\":0.11127114683345643},{\"id\":\"10265202\",\"x\":1.64453125,\"y\":0.42484818744518554},{\"id\":\"10350082\",\"x\":0.01416015625,\"y\":-0.001973545181522341},{\"id\":\"3153442\",\"x\":0.151611328125,\"y\":0.07957496812107644},{\"id\":\"12227148\",\"x\":0.9926265478134155,\"y\":0.8747378902914253},{\"id\":\"7801174\",\"x\":1.041458184417441,\"y\":0.6604046242774566},{\"id\":\"6708239\",\"x\":0.686279296875,\"y\":0.4386960456431176},{\"id\":\"9194315\",\"x\":0.46142578125,\"y\":0.26513622289570254},{\"id\":\"14476156\",\"x\":0.98388671875,\"y\":0.5085507819712426},{\"id\":\"15395575\",\"x\":1.55419921875,\"y\":0.5897915500657773},{\"id\":\"9429816\",\"x\":2.060302734375,\"y\":0.34576154565177253},{\"id\":\"4580985\",\"x\":1.950927734375,\"y\":0.5097817177258355},{\"id\":\"8557490\",\"x\":0.20282344531808438,\"y\":1.0856213872832372},{\"id\":\"4347288\",\"x\":0.23874195854181562,\"y\":1.119942196531792},{\"id\":\"11143668\",\"x\":1.483154296875,\"y\":0.31406532186172914},{\"id\":\"8125887\",\"x\":1.76171875,\"y\":0.2509806194897064},{\"id\":\"1134866\",\"x\":0.8980582524271845,\"y\":0.21444201312910285},{\"id\":\"8969467\",\"x\":1.300537109375,\"y\":0.15866156483682606},{\"id\":\"489355\",\"x\":1.110107421875,\"y\":0.08973001905522987},{\"id\":\"1641487\",\"x\":0.9716796875,\"y\":0.023260277166324318},{\"id\":\"3005616\",\"x\":0.7421875,\"y\":0.05434103307907127},{\"id\":\"13232691\",\"x\":0.6552734375,\"y\":0.12450353715409204},{\"id\":\"4030680\",\"x\":-0.264404296875,\"y\":0.07095850799425314},{\"id\":\"16114245\",\"x\":-0.37109375,\"y\":0.3663794828834703},{\"id\":\"338856\",\"x\":-0.248046875,\"y\":0.444850724416082},{\"id\":\"10220236\",\"x\":0.8548963545389563,\"y\":-0.01589595375722541},{\"id\":\"9465003\",\"x\":0.5,\"y\":0.5},{\"id\":\"8960594\",\"x\":0.5,\"y\":0.5},{\"id\":\"15379205\",\"x\":0.5,\"y\":0.5},{\"id\":\"66249\",\"x\":0.5,\"y\":0.5},{\"id\":\"2328557\",\"x\":0.5,\"y\":0.5},{\"id\":\"5960362\",\"x\":0.5,\"y\":0.5},{\"id\":\"8181315\",\"x\":0.5,\"y\":0.5},{\"id\":\"15508512\",\"x\":0.5,\"y\":0.5},{\"id\":\"573878\",\"x\":0.5,\"y\":0.5},{\"id\":\"3640888\",\"x\":0.5,\"y\":0.5},{\"id\":\"11905375\",\"x\":0.5,\"y\":0.5},{\"id\":\"8896571\",\"x\":0.5,\"y\":0.5},{\"id\":\"16293847\",\"x\":0.5,\"y\":0.5},{\"id\":\"5351373\",\"x\":0.5,\"y\":0.5},{\"id\":\"12712956\",\"x\":0.5,\"y\":0.5},{\"id\":\"9957622\",\"x\":0.5,\"y\":0.5},{\"id\":\"13964902\",\"x\":0.5,\"y\":0.5},{\"id\":\"78500\",\"x\":0.5,\"y\":0.5},{\"id\":\"5348671\",\"x\":0.5,\"y\":0.5},{\"id\":\"8351035\",\"x\":0.5,\"y\":0.5},{\"id\":\"10445879\",\"x\":0.5,\"y\":0.5},{\"id\":\"1031487\",\"x\":0.5,\"y\":0.5},{\"id\":\"6148233\",\"x\":0.5,\"y\":0.5},{\"id\":\"12231392\",\"x\":0.5,\"y\":0.5},{\"id\":\"6110330\",\"x\":0.5,\"y\":0.5},{\"id\":\"7471271\",\"x\":0.5,\"y\":0.5},{\"id\":\"12063512\",\"x\":0.5,\"y\":0.5},{\"id\":\"9911519\",\"x\":0.5,\"y\":0.5},{\"id\":\"13087239\",\"x\":0.5,\"y\":0.5},{\"id\":\"3786953\",\"x\":0.5,\"y\":0.5},{\"id\":\"1555578\",\"x\":0.5,\"y\":0.5},{\"id\":\"10038562\",\"x\":0.5,\"y\":0.5},{\"id\":\"13592446\",\"x\":0.5,\"y\":0.5},{\"id\":\"1728982\",\"x\":0.5,\"y\":0.5},{\"id\":\"null\",\"x\":0.5,\"y\":0.5},{\"id\":\"12066434\",\"x\":0.54253037884203,\"y\":0.3598265895953757}]`)
    localStorage.setItem("nodePosition", "[{\"id\":\"node4\",\"x\":0.6750788643533123,\"y\":0.6661849710982659},{\"id\":\"13126719\",\"x\":0.5020026702269693,\"y\":0.4956647398843931},{\"id\":\"319905\",\"x\":1.1904296875,\"y\":0.3565320870020541},{\"id\":\"1225927\",\"x\":0.65478515625,\"y\":0.7922780249636494},{\"id\":\"6755221\",\"x\":0.45746962115796996,\"y\":0.6575144508670521},{\"id\":\"2866431\",\"x\":1.134765625,\"y\":0.43038733072435836},{\"id\":\"9477608\",\"x\":-0.197509765625,\"y\":0.19928199396175683},{\"id\":\"8659983\",\"x\":-0.42578125,\"y\":0.2795995715097627},{\"id\":\"15153632\",\"x\":-0.483642578125,\"y\":0.14973744965726551},{\"id\":\"2487250\",\"x\":0.410888671875,\"y\":0.5100894629338996},{\"id\":\"820187\",\"x\":0.14501953125,\"y\":0.5725586748897942},{\"id\":\"4249941\",\"x\":-0.0390625,\"y\":0.326066844044267},{\"id\":\"12140456\",\"x\":0.093994140625,\"y\":0.3971525161269849},{\"id\":\"2579631\",\"x\":0.000732421875,\"y\":0.11127114683345643},{\"id\":\"10265202\",\"x\":1.64453125,\"y\":0.42484818744518554},{\"id\":\"10350082\",\"x\":0.01416015625,\"y\":-0.001973545181522341},{\"id\":\"3153442\",\"x\":0.151611328125,\"y\":0.07957496812107644},{\"id\":\"12227148\",\"x\":0.9926265478134155,\"y\":0.8747378902914253},{\"id\":\"7801174\",\"x\":1.041458184417441,\"y\":0.6604046242774566},{\"id\":\"6708239\",\"x\":0.686279296875,\"y\":0.4386960456431176},{\"id\":\"9194315\",\"x\":0.46142578125,\"y\":0.26513622289570254},{\"id\":\"14476156\",\"x\":0.98388671875,\"y\":0.5085507819712426},{\"id\":\"15395575\",\"x\":1.55419921875,\"y\":0.5897915500657773},{\"id\":\"9429816\",\"x\":2.060302734375,\"y\":0.34576154565177253},{\"id\":\"4580985\",\"x\":1.950927734375,\"y\":0.5097817177258355},{\"id\":\"8557490\",\"x\":0.20282344531808438,\"y\":1.0856213872832372},{\"id\":\"4347288\",\"x\":0.23874195854181562,\"y\":1.119942196531792},{\"id\":\"11143668\",\"x\":1.483154296875,\"y\":0.31406532186172914},{\"id\":\"8125887\",\"x\":1.76171875,\"y\":0.2509806194897064},{\"id\":\"1134866\",\"x\":0.8980582524271845,\"y\":0.21444201312910285},{\"id\":\"8969467\",\"x\":1.300537109375,\"y\":0.15866156483682606},{\"id\":\"489355\",\"x\":1.110107421875,\"y\":0.08973001905522987},{\"id\":\"1641487\",\"x\":0.9716796875,\"y\":0.023260277166324318},{\"id\":\"3005616\",\"x\":0.7421875,\"y\":0.05434103307907127},{\"id\":\"13232691\",\"x\":0.6552734375,\"y\":0.12450353715409204},{\"id\":\"4030680\",\"x\":-0.264404296875,\"y\":0.07095850799425314},{\"id\":\"16114245\",\"x\":-0.37109375,\"y\":0.3663794828834703},{\"id\":\"338856\",\"x\":-0.248046875,\"y\":0.444850724416082},{\"id\":\"10220236\",\"x\":0.8548963545389563,\"y\":-0.01589595375722541},{\"id\":\"9465003\",\"x\":0.5,\"y\":0.5},{\"id\":\"8960594\",\"x\":0.5,\"y\":0.5},{\"id\":\"15379205\",\"x\":0.5,\"y\":0.5},{\"id\":\"66249\",\"x\":0.5,\"y\":0.5},{\"id\":\"2328557\",\"x\":0.5,\"y\":0.5},{\"id\":\"5960362\",\"x\":0.5,\"y\":0.5},{\"id\":\"8181315\",\"x\":0.5,\"y\":0.5},{\"id\":\"15508512\",\"x\":0.5,\"y\":0.5},{\"id\":\"573878\",\"x\":0.5,\"y\":0.5},{\"id\":\"3640888\",\"x\":0.5,\"y\":0.5},{\"id\":\"11905375\",\"x\":0.5,\"y\":0.5},{\"id\":\"8896571\",\"x\":0.5,\"y\":0.5},{\"id\":\"16293847\",\"x\":0.5,\"y\":0.5},{\"id\":\"5351373\",\"x\":0.5,\"y\":0.5},{\"id\":\"12712956\",\"x\":0.5,\"y\":0.5},{\"id\":\"9957622\",\"x\":0.5,\"y\":0.5},{\"id\":\"13964902\",\"x\":0.5,\"y\":0.5},{\"id\":\"78500\",\"x\":0.5,\"y\":0.5},{\"id\":\"5348671\",\"x\":0.5,\"y\":0.5},{\"id\":\"8351035\",\"x\":0.5,\"y\":0.5},{\"id\":\"10445879\",\"x\":0.5,\"y\":0.5},{\"id\":\"1031487\",\"x\":0.5,\"y\":0.5},{\"id\":\"6148233\",\"x\":0.5,\"y\":0.5},{\"id\":\"12231392\",\"x\":0.5,\"y\":0.5},{\"id\":\"6110330\",\"x\":0.5,\"y\":0.5},{\"id\":\"7471271\",\"x\":0.5,\"y\":0.5},{\"id\":\"12063512\",\"x\":0.5,\"y\":0.5},{\"id\":\"9911519\",\"x\":0.5,\"y\":0.5},{\"id\":\"13087239\",\"x\":0.5,\"y\":0.5},{\"id\":\"3786953\",\"x\":0.5,\"y\":0.5},{\"id\":\"1555578\",\"x\":0.5,\"y\":0.5},{\"id\":\"10038562\",\"x\":0.5,\"y\":0.5},{\"id\":\"13592446\",\"x\":0.5,\"y\":0.5},{\"id\":\"1728982\",\"x\":0.5,\"y\":0.5},{\"id\":\"null\",\"x\":0.5,\"y\":0.5},{\"id\":\"12066434\",\"x\":0.54253037884203,\"y\":0.3598265895953757}]",)
    localStorage.setItem("nodes", "[{\"id\":\"319905\",\"name\":\"he suggested ice skating\",\"color\":\"#50fecc\",\"description\":\"\"},{\"id\":\"1225927\",\"name\":\"[LESS CHANCE OF BEING AN SIGN]\",\"color\":\"#b7c366\",\"description\":\"these are things that could be possible signs, but are not confirmed.\"},{\"id\":\"6755221\",\"name\":\"invited brigita as a third\",\"color\":\"#a9de37\",\"description\":\"they could've possibly had legitimate plans that fell through, but could've not too.\\n\\nwas I the third wheel?, or was brigita? or was brigita the mediator?\"},{\"id\":\"2866431\",\"name\":\"in the summer tho?\",\"color\":\"#c7de42\",\"description\":\"No description provided.\"},{\"id\":\"9477608\",\"name\":\"picking up my behavioral patterns\",\"color\":\"#b1c22e\",\"description\":\"Patrische said that he said this to her himself, but both denies this to my face and tells me that SHE was the one who said it.\"},{\"id\":\"8659983\",\"name\":\"texting\",\"color\":\"#791962\",\"description\":\"No description provided.\"},{\"id\":\"15153632\",\"name\":\"speech\",\"color\":\"#5eba56\",\"description\":\"No description provided.\"},{\"id\":\"2487250\",\"name\":\"[The Mall Trip] [#1]\",\"color\":\"#ef7859\",\"description\":\"This isn't actually a sign, but more of a divider to show where the sign is coming from\"},{\"id\":\"820187\",\"name\":\"\\\"All he wants to do is harass me\\\"\",\"color\":\"#ed02d3\",\"description\":\"it's not exactly a sign, but he's kinda calling me out?? I mean I could've actually had something to do but I didn't? tbf I didn't suggest the mall koi did so that could be a reason why he said this\"},{\"id\":\"4249941\",\"name\":\"[patrische]\",\"color\":\"#527ecf\",\"description\":\"AKA stuff patrische has told me\"},{\"id\":\"12140456\",\"name\":\"he doesn't deny being shipped\",\"color\":\"#a345c6\",\"description\":\"No description provided.\"},{\"id\":\"2579631\",\"name\":\"[Me]\",\"color\":\"#8ef413\",\"description\":\"AKA what i've noticed\"},{\"id\":\"10265202\",\"name\":\"[The Rinx] [#1]\",\"color\":\"#7eaf84\",\"description\":\"No description provided.\"},{\"id\":\"10350082\",\"name\":\"impatiently waited for me \",\"color\":\"#68c6d1\",\"description\":\"No description provided.\"},{\"id\":\"3153442\",\"name\":\"we bully each other\",\"color\":\"#8128cc\",\"description\":\"No description provided.\"},{\"id\":\"12227148\",\"name\":\"origami in my shirt pocket\",\"color\":\"#84d401\",\"description\":\"when trading origami he put the star origami in my shirt pocket?\"},{\"id\":\"7801174\",\"name\":\"made star origami\",\"color\":\"#e21fcd\",\"description\":\"No description provided.\"},{\"id\":\"6708239\",\"name\":\"origami \",\"color\":\"#6ba25e\",\"description\":\"No description provided.\"},{\"id\":\"9194315\",\"name\":\"Signs that Koi might like me\",\"color\":\"#cd34d2\",\"description\":\"No description provided.\"},{\"id\":\"14476156\",\"name\":\"I think he was blushing\",\"color\":\"#ff9e9e\",\"description\":\"It's\"},{\"id\":\"15395575\",\"name\":\"pulled me along by my hand\",\"color\":\"#263bd4\",\"description\":\"No description provided.\"},{\"id\":\"4580985\",\"name\":\"worried if I fell\",\"color\":\"#5dcc9b\",\"description\":\"he said that he was worried if I was going to, or looked like, fall\"},{\"id\":\"9429816\",\"name\":\"\\\"Yuri on Ice but we hate each other\\\"\",\"color\":\"#e9244a\",\"description\":\"why'd he pick THE gay anime?\"},{\"id\":\"11143668\",\"name\":\"Paid for my ticket\",\"color\":\"#a97bed\",\"description\":\"bc of this patrische is calling it a date, I dunno\\n\\nalso mf wouldn't let me pay him back for the rentals at a minimum >:/\"},{\"id\":\"8557490\",\"name\":\"Conspiracy\",\"color\":\"#ff5252\",\"description\":\"No description provided.\"},{\"id\":\"4347288\",\"name\":\"Dots\",\"color\":\"#8d9ffc\",\"description\":\"No description provided.\"},{\"id\":\"8125887\",\"name\":\"offered to put a bandaid on me\",\"color\":\"#b3d1ff\",\"description\":\"WHY DIDNT I TAKE IT\\nWHY DIDNT I TAKE IT\\nWHY DIDNT I TAKE IT\\nAAAAAAAAAAAAAAAAA\"},{\"id\":\"1134866\",\"name\":\"[Port Jeff] [#1]\",\"color\":\"#7c72cb\",\"description\":\"No description provided.\"},{\"id\":\"8969467\",\"name\":\"\\\"I care about your appearence\\\"\",\"color\":\"#9639f6\",\"description\":\"The dirt on my shirt????? maybe???? I cant remember the context behind this\"},{\"id\":\"489355\",\"name\":\"\\\"Homophobic\\\" [#1]\",\"color\":\"#b82e57\",\"description\":\"yeah i completely forgot the context behind this one, all i know is he called me homophobic and after I did my HUHHH he said that he meant transphobic but still it came out of left field\"},{\"id\":\"1641487\",\"name\":\"\\\"Homophobic\\\" [#2]\",\"color\":\"#d76078\",\"description\":\"uhhhh I said smthing like \\\"(something)... cant tell direction or do math\\\" (I was thinking of time not math)\\nhe called me homophobic\\nthen said bc \\\"I'm not gay it's bc the queer joke is that gay can't do math\\\"\"},{\"id\":\"3005616\",\"name\":\"\\\"Homoerotic\\\"\",\"color\":\"#cf8ffe\",\"description\":\"im very confused on this one bc i threatened to push him into the puddle??? smthing of the sort\"},{\"id\":\"13232691\",\"name\":\"[CHECK DESC.]\",\"color\":\"#fe614f\",\"description\":\"qoute was too long\\n \\\"I've spent the most time with anyone with you this summer\\\"\\n\\nhonestly koi's a bit of a introvert but still\"},{\"id\":\"4030680\",\"name\":\"I say 60%\",\"color\":\"#34f740\",\"description\":\"No description provided.\"},{\"id\":\"16114245\",\"name\":\"Patrische says he knows\",\"color\":\"#cdac92\",\"description\":\"No description provided.\"},{\"id\":\"338856\",\"name\":\"claims she's third wheeling the gc\",\"color\":\"#18f433\",\"description\":\"No description provided.\"},{\"id\":\"10220236\",\"name\":\"Glorious Put\",\"color\":\"#b75255\",\"description\":\"No description provided.\"}]")
    localStorage.setItem("links", "[{\"source\":\"2579631\",\"target\":\"10350082\"},{\"source\":\"2579631\",\"target\":\"3153442\"},{\"source\":\"2579631\",\"target\":\"9477608\"},{\"source\":\"4249941\",\"target\":\"9477608\"},{\"source\":\"9477608\",\"target\":\"15153632\"},{\"source\":\"9477608\",\"target\":\"8659983\"},{\"source\":\"4249941\",\"target\":\"12140456\"},{\"source\":\"2487250\",\"target\":\"820187\"},{\"source\":\"2487250\",\"target\":\"6755221\"},{\"source\":\"319905\",\"target\":\"2866431\"},{\"source\":\"9465003\",\"target\":\"null\"},{\"source\":\"8960594\",\"target\":\"null\"},{\"source\":\"15379205\",\"target\":\"null\"},{\"source\":\"66249\",\"target\":\"null\"},{\"source\":\"2328557\",\"target\":\"null\"},{\"source\":\"1225927\",\"target\":\"6755221\"},{\"source\":\"1225927\",\"target\":\"12227148\"},{\"source\":\"6708239\",\"target\":\"7801174\"},{\"source\":\"5960362\",\"target\":\"null\"},{\"source\":\"9194315\",\"target\":\"6708239\"},{\"source\":\"9194315\",\"target\":\"2579631\"},{\"source\":\"9194315\",\"target\":\"2487250\"},{\"source\":\"9194315\",\"target\":\"4249941\"},{\"source\":\"14476156\",\"target\":\"2487250\"},{\"source\":\"1225927\",\"target\":\"14476156\"},{\"source\":\"9194315\",\"target\":\"319905\"},{\"source\":\"319905\",\"target\":\"10265202\"},{\"source\":\"10265202\",\"target\":\"15395575\"},{\"source\":\"10265202\",\"target\":\"4580985\"},{\"source\":\"10265202\",\"target\":\"9429816\"},{\"source\":\"7801174\",\"target\":\"12227148\"},{\"source\":\"1225927\",\"target\":\"7801174\"},{\"source\":\"8557490\",\"target\":\"4347288\"},{\"source\":\"10265202\",\"target\":\"11143668\"},{\"source\":\"1225927\",\"target\":\"15395575\"},{\"source\":\"10265202\",\"target\":\"14476156\"},{\"source\":\"10265202\",\"target\":\"8125887\"},{\"source\":\"8181315\",\"target\":\"null\"},{\"source\":\"15508512\",\"target\":\"null\"},{\"source\":\"573878\",\"target\":\"null\"},{\"source\":\"3640888\",\"target\":\"null\"},{\"source\":\"11905375\",\"target\":\"null\"},{\"source\":\"8896571\",\"target\":\"null\"},{\"source\":\"16293847\",\"target\":\"null\"},{\"source\":\"5351373\",\"target\":\"null\"},{\"source\":\"12712956\",\"target\":\"null\"},{\"source\":\"9957622\",\"target\":\"null\"},{\"source\":\"13964902\",\"target\":\"null\"},{\"source\":\"78500\",\"target\":\"null\"},{\"source\":\"5348671\",\"target\":\"null\"},{\"source\":\"8351035\",\"target\":\"null\"},{\"source\":\"10445879\",\"target\":\"null\"},{\"source\":\"1031487\",\"target\":\"null\"},{\"source\":\"6148233\",\"target\":\"null\"},{\"source\":\"12231392\",\"target\":\"null\"},{\"source\":\"6110330\",\"target\":\"null\"},{\"source\":\"7471271\",\"target\":\"null\"},{\"source\":\"12063512\",\"target\":\"null\"},{\"source\":\"9911519\",\"target\":\"null\"},{\"source\":\"13087239\",\"target\":\"null\"},{\"source\":\"3786953\",\"target\":\"null\"},{\"source\":\"1555578\",\"target\":\"null\"},{\"source\":\"10038562\",\"target\":\"null\"},{\"source\":\"1134866\",\"target\":\"8969467\"},{\"source\":\"1134866\",\"target\":\"489355\"},{\"source\":\"1134866\",\"target\":\"3005616\"},{\"source\":\"1134866\",\"target\":\"1641487\"},{\"source\":\"13592446\",\"target\":\"null\"},{\"source\":\"1728982\",\"target\":\"null\"},{\"source\":\"9194315\",\"target\":\"1134866\"},{\"source\":\"1134866\",\"target\":\"13232691\"},{\"source\":\"1134866\",\"target\":\"14476156\"},{\"source\":\"4249941\",\"target\":\"16114245\"},{\"source\":\"2579631\",\"target\":\"4030680\"},{\"source\":\"4249941\",\"target\":\"338856\"}]")
}
if(nodes == null) {
  RESETLOCALSTOARTE()
  nodes = JSON.parse(localStorage.getItem('nodes'))
  links = JSON.parse(localStorage.getItem('links'))
  nodePosition = JSON.parse(localStorage.getItem('nodePosition'))

}
function rangeFix(number, min, max){
  if(number >= min && number <= max) return number;
  else if(number < min) return min;
  else return max;
}



function toggleNewNode(onoff) {
  if(onoff === undefined)
    togged = !togged;
  else
    togged = onoff;
  if(togged){
    document.getElementById("nodeModification").className = "hidden"
    document.getElementById("newNode").className = ""
    document.getElementById("closebtn").className = "hidden"
    document.getElementById("descript").className = "hidden"
    toggleDescript(false)
    
  } else {
    document.getElementById("nodeModification").className = ""
    document.getElementById("newNode").className = "hidden"
    document.getElementById("closebtn").className = "" 
    document.getElementById("descript").className = ""
  }
}
document.onkeydown = function(evt) {
  if (evt.keyCode == 27) {
      toggleDescript()
  }
};
function toggleDescript(onoff) {
  if(onoff === undefined)
    toggedDes = !toggedDes;
  else
  toggedDes = onoff;
  if(toggedDes){
    document.getElementById("descript").style.top= "11%";
    document.getElementById("descript").style.left= "10%";
    document.getElementById("descript").style.right= "10%";
    document.getElementById("descript").style.bottom= "10%";
  } else {
    document.getElementById("descript").style.top= "-10%";
    document.getElementById("descript").style.left= "-10%";
    document.getElementById("descript").style.right= "100%";
    document.getElementById("descript").style.bottom= "100%";
    
  }
}

function linkNodes(foo) {
  // link = foo;
  linker2 = true
  foo.disabled = true
  document.getElementById("newNode").disabled = true
  document.getElementById("CA").innerHTML = "(Un)Link Dots"
  // console.log("e")
}
function updateNODE(nodeID, name, color, description){
  // console.log("trying to update...")
  localStorage.setItem('nodes', JSON.stringify(nodes))
  localStorage.setItem('links', JSON.stringify(links))
  localStorage.setItem('nodePosition', JSON.stringify(nodePosition))
  // if(name == null) name = "null"
  // if(color == null) color = "null"
  // if(description == null) description = "null"
  // let data = {
  //   id:nodeID,
  //   name:name,
  //   color:color,
  //   description:description
  // }
  // fetch('node.php', {
  //   method: 'POST',
  //   headers: {
  //     'Content-Type': 'application/json'
  //   },
  //   body: JSON.stringify(data)
  // })
  //   .then(response => console.log(response))
  //   .then(responseData => {
      
  //     return responseData
  //   })
  //   .catch(error => {
      
  //     throw error
  //   });
}
  localStorage.setItem('nodes', JSON.stringify(nodes))
  localStorage.setItem('links', JSON.stringify(links))
  localStorage.setItem('nodePosition', JSON.stringify(nodePosition))
  let newNode2 = false
  let width = window.innerWidth*zoom;
  let height = window.innerHeight*zoom;
  let originalPos = JSON.parse(JSON.stringify(nodePosition));
  // if you resize the page
  window.addEventListener("resize", () => {
    width = window.innerWidth*zoom;
    height = window.innerHeight*zoom;
    console.log("size change")
    refresh()
});







window.addEventListener('mousewheel', (event) => {
  // console.log(event.wheelDelta)
  if(event.wheelDelta>0) zoom += 0.05
  else zoom -= 0.05
  zoom = rangeFix(zoom, 0.1, 2)
  width = window.innerWidth*zoom;
  height = window.innerHeight*zoom;
  if(!(zoom == 0.1 || zoom == 2))
  if(event.wheelDelta>0){
    totaloffsetX -= zoom*20;
    totaloffsetY -= zoom*20;
  } else {
    totaloffsetX += zoom*20;
    totaloffsetY += zoom*20;
  }
  // console.log(centerScreenX - mouseX)
  refresh()
});  



  const svg = d3.select('#diagram')
    .append('svg')
    .attr('width', '100%')
    .attr('height', '100%');
  
  document.getElementById("Change Name").addEventListener("keyup", () => {
    let name = document.getElementById("Change Name").value;
    updateNODE(document.getElementById('linker').class, name, null, null)
    var index = nodes.findIndex(obj => obj.id==document.getElementById('linker').class);
    if(index!=-1){
      // document.getElementById('name').innerText = name
      
      nodes[index].name=name;
      refresh()
    }
  });
  document.getElementById("descript").addEventListener("keyup", () => {
    let description = document.getElementById("descript").value;
    updateNODE(document.getElementById('linker').class, null, null, description)
    var index = nodes.findIndex(obj => obj.id==document.getElementById('linker').class);
    if(index!=-1){
      nodes[index].description=description;
    }
  });
  document.getElementById("Change Color").addEventListener("input", () => {
    let color = document.getElementById("Change Color").value;
    var index = nodes.findIndex(obj => obj.id==document.getElementById('linker').class);
    if(index!=-1){
      nodes[index].color=color;
    }
    refresh()
  });
  function zoomed(soom){
    zoom += soom
    zoom = rangeFix(zoom, 0.1, 2)
    width = window.innerWidth*zoom;
    height = window.innerHeight*zoom;
    if(!(zoom == 0.1 || zoom == 2))
    if(soom>0){
      totaloffsetX -= zoom*20;
      totaloffsetY -= zoom*20;
    } else {
      totaloffsetX += zoom*20;
      totaloffsetY += zoom*20;
    }
    refresh()
    // console.log(centerScreenX - mouseX)
  }
  // document.getElementById('zoomin').addEventListener('click', zoomed(.1))
  // document.getElementById('zoomout').addEventListener('click', zoomed(-.1))
  document.getElementById("Change Color").addEventListener("change", () => {
    let color = document.getElementById("Change Color").value;
    updateNODE(document.getElementById('linker').class, null, color, null)
  });
  document.getElementById("delete Node").addEventListener("click", () => {
    let name = confirm('Are you sure you want to delete this node?');
    // updateJSON(document.getElementById('linker').class, true)
    // updateLINK(document.getElementById('linker').class, "null")
    var index = nodes.findIndex(obj => obj.id==document.getElementById('linker').class);
    nodes.splice(index, 1)
    // console.log(links)
    for(let i = links.length-1; i >= 0; i--)
      if(links[i].source == document.getElementById('linker').class || links[i].target == document.getElementById('linker').class)
        links.splice(i, 1)
    clearBar()
    updateNODE(document.getElementById('linker').class, null, null, null)
    refresh()
  });
  
  function refresh() { // initalizes the lines
  svg.html("")
  originalPos = JSON.parse(JSON.stringify(nodePosition));
  svg.selectAll('line')
    .data(links)
    .enter()
    .append('line')
    .attr('x1', d => getNodeX(d.source)*width+offsetX+totaloffsetX)
    .attr('y1', d => getNodeY(d.source)*height+offsetY+totaloffsetY)
    .attr('x2', d => getNodeX(d.target)*width+offsetX+totaloffsetX)
    .attr('y2', d => getNodeY(d.target)*height+offsetY+totaloffsetY)
    .attr('stroke-width', zoom)
    .attr('stroke', 'lightgray');

  // initalizes the nodes
  const nodesSelection = svg.selectAll('.node')
    .data(nodes)
    .enter()
    .append('g')
    .attr('class', 'node')
    .attr("transform", `scale(${zoom},${zoom})`)
    .call(d3.drag()
      .on('start', handleDragStart)
      .on('drag', handleDrag)
      .on('end', handleDragEnd)
    )
    .on('click', handleClick);

  nodesSelection.append('circle')
    .attr('id', d => d.id)
    .attr('cx', d => (getNodeX(d.id) * width+offsetX+totaloffsetX) * (1/zoom))
    .attr('cy', d => (getNodeY(d.id) * height+offsetY+totaloffsetY) * (1/zoom))
    .attr('r', d => 10+countAppearences(d.id, true, false)*1)
    .attr('fill', d => d.color);

  nodesSelection.append('text')
    .attr('class', 'label')
    .attr('x', d => (getNodeX(d.id) * width+offsetX+totaloffsetX)* (1/zoom))
    .attr('y', d => (getNodeY(d.id) * height+offsetY+totaloffsetY) * (1/zoom)+20) // Adjust the y position for the label
    .text(d => d.name);
}
console.log(nodes == null)
refresh()
    // helper function that takes a number, then keeps it within a min/max range
    // OLD HELPER FUNCTION
  
  // another helper function that simply asks the position JSON for a X value of a node
  // also has a catch (the index being -1) incase it doesnt exist which creates a new position in the JSON
  function getNodeX(nodeId) {
    var index = nodePosition.findIndex(obj => obj.id==nodeId);
    if(index == -1){
      nodePosition.push({
       id:nodeId,
       x:.5,
       y:.5
      })
      // refresh()
      return .5
     }
    return nodePosition[index].x;
  }

  // same as above, but for Y
  function getNodeY(nodeId) {
    var index = nodePosition.findIndex(obj => obj.id==nodeId);
    if(index == -1){
     nodePosition.push({
      id:nodeId,
      x:.5,
      y:.5
     })
    //  refresh()
     return .5
    }
    return nodePosition[index].y;
    
  }
  
  function handleClick(event, d) {
    // console.log(event)
    // console.log(d)
    if(link != null && link != d.id) {
      console.log(`linking ${link} and ${d.id}`)
      updateLINK(link, d.id)
      found = false
      for(let i = links.length-1; i >= 0; i--)
        // console.log(links[i])
        if((links[i].source == link && links[i].target == d.id) || (links[i].target == link && links[i].source == d.id)){
          found = true;
          links.splice(i, 1)
        }
      if(!found)
        links.push({
          "source":link,
          "target":d.id
        });
      link = null;
      refresh()
    } else {
      toggleNewNode(false)
      // document.getElementById("name").innerHTML = d.name;
      document.getElementById("descript").value = d.description;
      document.getElementById("linker").class = d.id;
      document.getElementById("Change Name").value = d.name;
      document.getElementById("Change Color").value = d.color;
    }
  }
  document.getElementById("newNode").addEventListener('click', () => {
    newNode2 = true
    document.getElementById("newNode").disabled = true
    document.getElementById("linker").disabled = true
    document.getElementById("CA").innerHTML = "Place Dot"
  });
  document.addEventListener('click', function(e) {
    const target = e.target;
    if (!target.matches('circle') && !target.matches('button') && !target.matches('input') && !target.matches('a')&& !target.matches('textarea')) {
      if(link == null){
        clearBar()
        if(newNode2){  
          newNode2 = false
          document.getElementById("newNode").disabled = false
          document.getElementById("linker").disabled = false
          document.getElementById("CA").innerHTML = "Edit Dots"
          let randomColor = "#"+Math.floor(Math.random()*16777215).toString(16);
          let id = ""+Math.floor(Math.random()*16777215)
          let name = generateName()
          nodes.push({
            id:id,
            name:name,
            color:randomColor, 
            description:"No description provided."
          });
          updateNODE(id,name,randomColor, "No description provided.")
          nodePosition.push({
            id:id,
            x:(e.clientX/width)-(totaloffsetX/width),
            y:(e.clientY/height)-(totaloffsetY/height)
          });
          refresh()
        }
      }
    }
  });
  document.addEventListener('mousedown', function(event) {
    const target = event.target;
    if (!target.matches('circle') && !target.matches('input') && !target.matches('a')&& !target.matches('textarea')) {
      startOffsetX=event.x
      startOffsetY=event.y
      mouseIsDown=true
      refresh()
    }
  });
  document.addEventListener('mousemove', function(event) {
    const target = event.target;
    
    if (mouseIsDown) {
      offsetX=-(startOffsetX-event.x) 
      offsetY=-(startOffsetY-event.y)
      refresh()
      // console.log(offsetX)
    }
  });
  document.addEventListener('mouseup', function(event) {
    if (mouseIsDown) {
      mouseIsDown = !mouseIsDown
      totaloffsetX+=offsetX
      totaloffsetY+=offsetY
      offsetX=0
      offsetY=0
      refresh()
    }
  });
  
  document.addEventListener('touchstart', function(event) {
    const target = event.target;
    // console.log(event)
    if (!target.matches('circle') && !target.matches('input') && !target.matches('a')&& !target.matches('textarea')) {
      startOffsetX=event.touches[0].clientX
      startOffsetY=event.touches[0].clientY
      mouseIsDown=true
      refresh()
    }
  });
  document.addEventListener('touchmove', function(event) {
    const target = event.target;
    
    if (mouseIsDown) {
      offsetX=-(startOffsetX-event.touches[0].clientX) 
      offsetY=-(startOffsetY-event.touches[0].clientY)
      refresh()
      // console.log(offsetX)
    }
  });
  document.addEventListener('touchend', function(event) {
    if (mouseIsDown) {
      mouseIsDown = !mouseIsDown
      totaloffsetX+=offsetX
      totaloffsetY+=offsetY
      offsetX=0
      offsetY=0
      refresh()
    }
  });
  function clearBar(){
    // document.getElementById("name").innerHTML = "None Selected";
    document.getElementById("descript").value = "";
    document.getElementById("linker").class = null;
    toggleNewNode(true)
  }

  function handleDragStart(event, d) {
    // currently unsed
    // console.log(linker2)
    if(linker2) {
      link = d.id;
      tempLink = svg
        .append('line')
        .attr('x1', getNodeX(d.id) * width + offsetX + totaloffsetX)
        .attr('y1', getNodeY(d.id) * height + offsetY + totaloffsetY)
        .attr('x2', getNodeX(d.id) * width + offsetX + totaloffsetX)
        .attr('y2', getNodeY(d.id) * height + offsetY + totaloffsetY)
        .attr('stroke', 'lightgray')
        .attr('stroke-width', 2 / zoom);

    }
  }
  // Drag function, AKA move the node to the mouse position
  function handleDrag(event, d) {
    const { x, y } = event;
    if(link == null){
      toggleNewNode(false)
      // document.getElementById("name").innerHTML = d.name;
      document.getElementById("descript").value = d.description;
      document.getElementById("linker").class = d.id;
      document.getElementById("Change Name").value = d.name;
      document.getElementById("Change Color").value = d.color;
      var index = nodePosition.findIndex(obj => obj.id==d.id);
      // console.log(nodePosition[index].x);
      nodePosition[index].x = (x-totaloffsetX)/width
      nodePosition[index].y = (y-totaloffsetY)/height
      const group = d3.select(this);
      // console.log(originalPos)
      group.attr('transform', `scale(${zoom},${zoom}), translate(${(-((originalPos[index].x * width) - (nodePosition[index].x * width)))* (1/zoom)},${(-((originalPos[index].y * height) - (nodePosition[index].y * height))* (1/zoom))})`);
      updateLinks();
    } else if(linker2) tempLink.attr('x2', event.x).attr('y2', event.y);
    
  }
  // at the end of the drag, update the global JSON
  function handleDragEnd(e, d) {
    const targetNode = findNodeAtCoordinates(e.x, e.y);
    if (targetNode && link) {
      endNode = targetNode.id;
      // Create the link between startNode and endNode
      if(link != endNode) {
        
        console.log(`linking ${link} and ${endNode}`)
        updateLINK(link, endNode)
        found = false
        for(let i = links.length-1; i >= 0; i--)
          if((links[i].source == link && links[i].target == endNode) || (links[i].target == link && links[i].source == endNode)){
            found = true;
            links.splice(i, 1)
          }
        if(!found)
          links.push({
            "source":link,
            "target":endNode
          });
        refresh()
        }
      } else updateJSON(d.id) 
      if (tempLink) {
        tempLink.remove();
        tempLink = null;
      }
      linker2 = false
      link = null;
      document.getElementById('linker').disabled = false
      document.getElementById("newNode").disabled = false
      document.getElementById("CA").innerHTML = "Edit Dots"
    
  }

  function findNodeAtCoordinates(x, y) {
    // Helper function to find the node at the given coordinates
    // Loop through the nodes and check if the coordinates are within the node's circle
    const node = nodes.find((node) => {
      const nodeX = getNodeX(node.id) * width + offsetX + totaloffsetX;
      const nodeY = getNodeY(node.id) * height + offsetY + totaloffsetY;
      const distanceSquared = (nodeX - x) ** 2 + (nodeY - y) ** 2;
      return distanceSquared <= (10 + countAppearences(node.id, true, false) * 1) ** 2;
    });
    return node;
  }
  
  // support code to find the amount of times a node appears
  function countAppearences(id, source, target){
    
    if(source === undefined) source = true;
    if(target === undefined) target = true;
    let count = 0;
    links.forEach(link => {
      if(link.source == id && source)
          count++;
        if(link.target == id && target)
          count++;
    });
    // console.log(count)
    return count
  }



  // ajusts the nodes if the page is resized
  // OUTDATED CODE aka no use for it now
  function updateNodes() {
    svg.selectAll('.node')
      .attr('cx', d => getNodeX(d.id)*width)
      .attr('cy', d => getNodeY(d.id)*height)
    }
  // ajusts the lines if the page is resized
  function updateLinks() {
    svg.selectAll('line')
      .attr('x1', d => getNodeX(d.source)*width+offsetX+totaloffsetX)
      .attr('y1', d => getNodeY(d.source)*height+offsetY+totaloffsetY)
      .attr('x2', d => getNodeX(d.target)*width+offsetX+totaloffsetX)
      .attr('y2', d => getNodeY(d.target)*height+offsetY+totaloffsetY);
  }

  // makes a php post request to fix.php which will update the global JSON
  function updateJSON(nodeID, deleted = false){
    // console.log("trying to update...")
    localStorage.setItem('nodes', JSON.stringify(nodes))
    localStorage.setItem('links', JSON.stringify(links))
    localStorage.setItem('nodePosition', JSON.stringify(nodePosition))
    // var index = nodePosition.findIndex(obj => obj.id==nodeID);
    // if(deleted){
    //   nodePosition[index].x = "null"
    //   nodePosition[index].y = "null"
    // }
    // // console.log(nodePosition[index])
    // fetch('position.php', {
    //   method: 'POST',
    //   headers: {
    //     'Content-Type': 'application/json'
    //   },
    //   body: JSON.stringify(nodePosition[index])
    // })
    //   .then(response => console.log(response))
    //   .then(responseData => {
        
    //     return responseData
    //   })
    //   .catch(error => {
        
    //     throw error
    //   });
  }

  function updateLINK(originalNode, targetNode){
    // console.log("trying to update...")
    localStorage.setItem('nodes', JSON.stringify(nodes))
    localStorage.setItem('links', JSON.stringify(links))
    localStorage.setItem('nodePosition', JSON.stringify(nodePosition))
  //   let data = {
  //     source:originalNode,
  //     target:targetNode
  //   }
  //   fetch('links.php', {
  //     method: 'POST',
  //     headers: {
  //       'Content-Type': 'application/json'
  //     },
  //     body: JSON.stringify(data)
  //   })
  //     .then(response => console.log(response))
  //     .then(responseData => {
        
  //       return responseData
  //     })
  //     .catch(error => {
        
  //       throw error
  //     });
  }

  